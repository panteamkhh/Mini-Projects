# Day 17 — Statistical Analysis

A `StatisticalAnalyzer` class that runs a proper statistical
analysis of an A/B test using **scipy** — not just "the treatment
mean is bigger," but actual hypothesis testing, confidence
intervals, and effect size, ending in a data-backed recommendation.

---

## What it answers

- Is the **conversion rate** difference between control and
  treatment statistically significant? (two-proportion z-test)
- Is the **session duration** difference significant? (independent
  t-test, with a Levene's test to check the equal-variance
  assumption first, rather than assuming it)
- What's the **95% confidence interval** for the mean of a metric in
  each group?
- How large is the effect, in standardized terms? (**Cohen's d**)
- Should we ship the treatment, or collect more data?

A deliberately realistic detail: with 500 users per group, the
conversion-rate lift in the sample data (~33% relative lift) is
**not** statistically significant (p≈0.11) even though it looks
big — a genuinely common and important result to be able to explain
to a stakeholder who just wants to see the bigger number and ship.

---

## Key concepts used

- Two-proportion z-test for comparing conversion rates
- Independent-samples t-test (`scipy.stats.ttest_ind`) for comparing
  a continuous metric between groups
- Testing the equal-variance assumption first (`scipy.stats.levene`)
  instead of assuming Welch's or Student's t-test blindly
- Confidence intervals via the t-distribution (`scipy.stats.t.interval`)
- Effect size (Cohen's d) — distinguishing statistical significance
  from practical significance
- Turning test statistics into a plain-English, decision-oriented
  verdict instead of stopping at a p-value

---

## Dataset

`data/ab_test_results.csv` (1,000 users, 500 per group) is generated
by `generate_data.py` with a genuine, realistic conversion lift
(10% → 13.5%) and session-duration lift built in — not pure noise.

```bash
python generate_data.py
```

## How to run

```bash
python main.py
```

## How to test

```bash
pip install -r ../../requirements.txt
pytest test_main.py
```
