"""
Day 17 - Statistical Analysis
Generates a reproducible A/B test dataset (data/ab_test_results.csv):
a control group and a treatment group (e.g. a new checkout page),
with a genuine (but modest and realistic) lift in conversion rate
and revenue, so hypothesis tests below actually have something real
to detect.
"""

import numpy as np
import pandas as pd

RANDOM_SEED = 17
N_PER_GROUP = 500

CONTROL_CONVERSION_RATE = 0.10
TREATMENT_CONVERSION_RATE = 0.135  # a modest, realistic lift

CONTROL_SESSION_MEAN = 180.0    # seconds
TREATMENT_SESSION_MEAN = 195.0  # seconds
SESSION_STD = 45.0

REVENUE_PER_CONVERSION_MEAN = 45.0
REVENUE_PER_CONVERSION_STD = 15.0


def _build_group(
    rng: np.random.Generator,
    group_name: str,
    n: int,
    conversion_rate: float,
    session_mean: float,
) -> pd.DataFrame:
    converted = rng.binomial(1, conversion_rate, size=n)
    session_duration = np.clip(
        rng.normal(session_mean, SESSION_STD, size=n), 10, None
    ).round(1)

    revenue = np.where(
        converted == 1,
        np.clip(
            rng.normal(REVENUE_PER_CONVERSION_MEAN, REVENUE_PER_CONVERSION_STD, size=n),
            5, None,
        ),
        0.0,
    ).round(2)

    return pd.DataFrame({
        "user_id": [f"{group_name[:1].upper()}-{i:04d}" for i in range(1, n + 1)],
        "group": group_name,
        "session_duration": session_duration,
        "converted": converted,
        "revenue": revenue,
    })


def generate_dataset(n_per_group: int = N_PER_GROUP, seed: int = RANDOM_SEED) -> pd.DataFrame:
    """Build a synthetic A/B test DataFrame with a realistic conversion lift."""
    rng = np.random.default_rng(seed)

    control = _build_group(
        rng, "control", n_per_group, CONTROL_CONVERSION_RATE, CONTROL_SESSION_MEAN
    )
    treatment = _build_group(
        rng, "treatment", n_per_group, TREATMENT_CONVERSION_RATE, TREATMENT_SESSION_MEAN
    )

    return pd.concat([control, treatment], ignore_index=True)


if __name__ == "__main__":
    dataset = generate_dataset()
    dataset.to_csv("data/ab_test_results.csv", index=False)
    print(f"Wrote {len(dataset)} rows to data/ab_test_results.csv")
