"""
Day 19 - Interactive Dashboard

A Streamlit sales dashboard: sidebar filters (region, category,
segment, date range), KPI cards, a revenue trend chart, a category
breakdown, and a filtered, downloadable data table.

The data/filtering logic lives in `DashboardData`, kept completely
separate from Streamlit calls, so it's testable with plain pytest
without needing to run a Streamlit server. The UI section at the
bottom is what actually renders when you run:

    streamlit run main.py
"""

from __future__ import annotations

from pathlib import Path

import pandas as pd


class DashboardData:
    """Loads, filters, and summarizes the sales dataset for the dashboard."""

    def __init__(self, csv_path: str | Path = "data/sales_dashboard_data.csv") -> None:
        self.csv_path = Path(csv_path)
        self.df: pd.DataFrame = self._load()

    # ------------------------------------------------------------------
    # Loading
    # ------------------------------------------------------------------
    def _load(self) -> pd.DataFrame:
        if not self.csv_path.exists():
            raise FileNotFoundError(
                f"Dataset not found at {self.csv_path}. "
                "Run `python generate_data.py` first."
            )
        return pd.read_csv(self.csv_path, parse_dates=["order_date"])

    # ------------------------------------------------------------------
    # Filter options (populate sidebar widgets)
    # ------------------------------------------------------------------
    def filter_options(self) -> dict:
        return {
            "regions": sorted(self.df["region"].unique()),
            "categories": sorted(self.df["product_category"].unique()),
            "segments": sorted(self.df["customer_segment"].unique()),
            "min_date": self.df["order_date"].min().date(),
            "max_date": self.df["order_date"].max().date(),
        }

    # ------------------------------------------------------------------
    # Filtering
    # ------------------------------------------------------------------
    def filter_data(
        self,
        regions: list[str] | None = None,
        categories: list[str] | None = None,
        segments: list[str] | None = None,
        date_range: tuple | None = None,
    ) -> pd.DataFrame:
        """Apply any combination of sidebar filters to the raw data."""
        result = self.df

        if regions:
            result = result[result["region"].isin(regions)]
        if categories:
            result = result[result["product_category"].isin(categories)]
        if segments:
            result = result[result["customer_segment"].isin(segments)]
        if date_range:
            start, end = date_range
            result = result[
                (result["order_date"] >= pd.Timestamp(start))
                & (result["order_date"] <= pd.Timestamp(end))
            ]

        return result

    # ------------------------------------------------------------------
    # Summaries (all operate on an already-filtered DataFrame)
    # ------------------------------------------------------------------
    @staticmethod
    def kpis(df: pd.DataFrame) -> dict:
        if df.empty:
            return {"total_revenue": 0.0, "total_orders": 0, "avg_order_value": 0.0}
        return {
            "total_revenue": round(df["revenue"].sum(), 2),
            "total_orders": len(df),
            "avg_order_value": round(df["revenue"].mean(), 2),
        }

    @staticmethod
    def revenue_trend(df: pd.DataFrame) -> pd.Series:
        if df.empty:
            return pd.Series(dtype=float)
        monthly = df.set_index("order_date")["revenue"].resample("ME").sum()
        monthly.index = monthly.index.strftime("%Y-%m")
        return monthly.round(2)

    @staticmethod
    def revenue_by_category(df: pd.DataFrame) -> pd.Series:
        if df.empty:
            return pd.Series(dtype=float)
        return df.groupby("product_category")["revenue"].sum().sort_values(ascending=False).round(2)

    @staticmethod
    def revenue_by_region(df: pd.DataFrame) -> pd.Series:
        if df.empty:
            return pd.Series(dtype=float)
        return df.groupby("region")["revenue"].sum().sort_values(ascending=False).round(2)


# ----------------------------------------------------------------------
# Streamlit UI (runs only when launched via `streamlit run main.py`)
# ----------------------------------------------------------------------
if __name__ == "__main__":
    import streamlit as st

    st.set_page_config(page_title="Sales Dashboard", layout="wide")
    st.title("📊 Sales Performance Dashboard")

    data = DashboardData()
    options = data.filter_options()

    with st.sidebar:
        st.header("Filters")
        selected_regions = st.multiselect("Region", options["regions"])
        selected_categories = st.multiselect("Product Category", options["categories"])
        selected_segments = st.multiselect("Customer Segment", options["segments"])
        selected_date_range = st.date_input(
            "Order Date Range",
            value=(options["min_date"], options["max_date"]),
            min_value=options["min_date"],
            max_value=options["max_date"],
        )

    date_range = selected_date_range if len(selected_date_range) == 2 else None
    filtered = data.filter_data(
        regions=selected_regions or None,
        categories=selected_categories or None,
        segments=selected_segments or None,
        date_range=date_range,
    )

    kpis = data.kpis(filtered)
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Revenue", f"${kpis['total_revenue']:,.0f}")
    col2.metric("Total Orders", f"{kpis['total_orders']:,}")
    col3.metric("Avg Order Value", f"${kpis['avg_order_value']:,.2f}")

    st.subheader("Monthly Revenue Trend")
    st.line_chart(data.revenue_trend(filtered))

    chart_col, table_col = st.columns([1, 1])
    with chart_col:
        st.subheader("Revenue by Category")
        st.bar_chart(data.revenue_by_category(filtered))
    with table_col:
        st.subheader("Revenue by Region")
        st.bar_chart(data.revenue_by_region(filtered))

    st.subheader(f"Filtered Orders ({len(filtered):,} rows)")
    st.dataframe(filtered, width="stretch")

    st.download_button(
        "Download filtered data as CSV",
        data=filtered.to_csv(index=False),
        file_name="filtered_sales_data.csv",
        mime="text/csv",
    )
