"""
Unit tests for Day 19 - Interactive Dashboard.

Split in two:
- DashboardData tests: plain pytest, no Streamlit involved.
- App smoke tests: use Streamlit's AppTest framework to actually run
  the dashboard script and check it renders without error.
"""

import pandas as pd
import pytest
from streamlit.testing.v1 import AppTest

from generate_data import generate_dataset
from main import DashboardData


@pytest.fixture
def dashboard(tmp_path) -> DashboardData:
    csv_path = tmp_path / "sales_dashboard_data.csv"
    generate_dataset(n_rows=200, seed=6).to_csv(csv_path, index=False)
    return DashboardData(csv_path=csv_path)


# ----------------------------------------------------------------------
# DashboardData
# ----------------------------------------------------------------------

def test_missing_file_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        DashboardData(csv_path=tmp_path / "nope.csv")


def test_filter_options_returns_expected_keys(dashboard):
    options = dashboard.filter_options()
    assert set(options.keys()) == {"regions", "categories", "segments", "min_date", "max_date"}
    assert len(options["regions"]) > 0


def test_filter_data_no_filters_returns_everything(dashboard):
    result = dashboard.filter_data()
    assert len(result) == len(dashboard.df)


def test_filter_data_by_region(dashboard):
    region = dashboard.df["region"].iloc[0]
    result = dashboard.filter_data(regions=[region])
    assert (result["region"] == region).all()


def test_filter_data_by_multiple_dimensions(dashboard):
    region = dashboard.df["region"].iloc[0]
    category = dashboard.df["product_category"].iloc[0]
    result = dashboard.filter_data(regions=[region], categories=[category])
    assert (result["region"] == region).all()
    assert (result["product_category"] == category).all()


def test_filter_data_by_date_range(dashboard):
    min_date = dashboard.df["order_date"].min().date()
    result = dashboard.filter_data(date_range=(min_date, min_date))
    assert (result["order_date"].dt.date == min_date).all()


def test_kpis_on_nonempty_data(dashboard):
    kpis = DashboardData.kpis(dashboard.df)
    assert kpis["total_orders"] == len(dashboard.df)
    assert kpis["total_revenue"] > 0
    assert kpis["avg_order_value"] > 0


def test_kpis_on_empty_dataframe(dashboard):
    empty = dashboard.df.iloc[0:0]
    kpis = DashboardData.kpis(empty)
    assert kpis == {"total_revenue": 0.0, "total_orders": 0, "avg_order_value": 0.0}


def test_revenue_trend_on_empty_dataframe_returns_empty_series(dashboard):
    empty = dashboard.df.iloc[0:0]
    trend = DashboardData.revenue_trend(empty)
    assert isinstance(trend, pd.Series)
    assert trend.empty


def test_revenue_by_category_sums_to_total(dashboard):
    by_category = DashboardData.revenue_by_category(dashboard.df)
    assert round(by_category.sum(), 2) == round(dashboard.df["revenue"].sum(), 2)


def test_revenue_by_region_sorted_descending(dashboard):
    by_region = DashboardData.revenue_by_region(dashboard.df)
    assert list(by_region) == sorted(by_region, reverse=True)


# ----------------------------------------------------------------------
# Streamlit app smoke tests (AppTest actually runs main.py's UI section)
# ----------------------------------------------------------------------

def test_app_runs_without_exception():
    at = AppTest.from_file("main.py")
    at.run(timeout=15)
    assert not at.exception


def test_app_shows_title_and_kpi_metrics():
    at = AppTest.from_file("main.py")
    at.run(timeout=15)

    assert len(at.title) == 1
    metrics = {m.label: m.value for m in at.main.get("metric")}
    assert set(metrics.keys()) == {"Total Revenue", "Total Orders", "Avg Order Value"}


def test_app_sidebar_has_filters():
    at = AppTest.from_file("main.py")
    at.run(timeout=15)

    assert len(at.sidebar.multiselect) == 3  # region, category, segment


def test_app_selecting_a_region_filters_results():
    at = AppTest.from_file("main.py")
    at.run(timeout=15)

    region_filter = at.sidebar.multiselect[0]
    region_filter.select(region_filter.options[0])
    at.run(timeout=15)

    assert not at.exception
